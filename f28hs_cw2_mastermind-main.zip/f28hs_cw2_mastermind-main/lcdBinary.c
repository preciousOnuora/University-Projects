/* ***************************************************************************** */
/* You can use this file to define the low-level hardware control fcts for       */
/* LED, button and LCD devices.                                                  */ 
/* Note that these need to be implemented in Assembler.                          */
/* You can use inline Assembler code, or use a stand-alone Assembler file.       */
/* Alternatively, you can implement all fcts directly in master-mind.c,          */  
/* using inline Assembler code there.                                            */
/* The Makefile assumes you define the functions here.                           */
/* ***************************************************************************** */


#ifndef	TRUE
#  define	TRUE	(1==1)
#  define	FALSE	(1==2)
#endif

#define	PAGE_SIZE		(4*1024)
#define	BLOCK_SIZE		(4*1024)

#define	INPUT			 0
#define	OUTPUT			 1

#define	LOW			 0
#define	HIGH			 1


// APP constants   ---------------------------------

// Wiring (see call to lcdInit in main, using BCM numbering)
// NB: this needs to match the wiring as defined in master-mind.c

#define STRB_PIN 24
#define RS_PIN   25
#define DATA0_PIN 23
#define DATA1_PIN 10
#define DATA2_PIN 27
#define DATA3_PIN 22

// -----------------------------------------------------------------------------
// includes 
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/types.h>
#include <time.h>

// -----------------------------------------------------------------------------
// prototypes

int failure (int fatal, const char *message, ...);

// -----------------------------------------------------------------------------
// Functions to implement here (or directly in master-mind.c)

/* this version needs gpio as argument, because it is in a separate file */
void digitalWrite(uint32_t *gpio, int pin, int value) {
  if (value == HIGH) {
      // Set pin to HIGH
      __asm__ volatile (
          "mov r0, %0\n\t"          // Load the base address of gpio
          "mov r1, %1\n\t"          // Load the pin number
          "mov r2, #1\n\t"          // Value to write (HIGH)
          "lsl r1, r1, #2\n\t"      // Shift left to get the correct register offset (assuming 4-byte offset)
          "str r2, [r0, r1]\n\t"    // Store value at gpio + (pin * 4)
          :
          : "r"(gpio), "r"(pin)
          : "r0", "r1", "r2", "memory"
      );
  } else {
      // Set pin to LOW
      __asm__ volatile (
          "mov r0, %0\n\t"          // Load the base address of gpio
          "mov r1, %1\n\t"          // Load the pin number
          "mov r2, #0\n\t"          // Value to write (LOW)
          "lsl r1, r1, #2\n\t"      // Shift left to get the correct register offset (assuming 4-byte offset)
          "str r2, [r0, r1]\n\t"    // Store value at gpio + (pin * 4)
          :
          : "r"(gpio), "r"(pin)
          : "r0", "r1", "r2", "memory"
      );
  }
}


// adapted from setPinMode
void pinMode(uint32_t *gpio, int pin, int mode) {
  int fSel = pin / 10;         // GPIO function select register index (pins are divided by 10)
  int shift = (pin % 10) * 3;  // Shift within the register (3 bits per pin)
  
  __asm__ volatile (
      "ldr r0, [%0, %1]\n\t"     // Load the correct GPIO Function Select register into r0
      "mov r1, %2\n\t"            // Load the mode (INPUT or OUTPUT) into r1
      "lsl r1, r1, %3\n\t"        // Shift the mode value to the correct bit position
      "bic r0, r0, #7\n\t"        // Clear the 3 bits corresponding to the pin (set as 000)
      "orr r0, r0, r1\n\t"        // Set the mode (input/output) by OR'ing
      "str r0, [%0, %1]\n\t"      // Store the updated value back to the register
      :
      : "r"(gpio), "r"(fSel * 4), "r"(mode), "r"(shift)
      : "r0", "r1", "memory"
  );
}


void writeLED(uint32_t *gpio, int led, int value) {
  //uint32_t *led_address = gpio + (led * 4); // Calculate the address of the GPIO register

  asm volatile(
    // Load the GPIO base address into R1
    "LDR R1, %[gpio]\n"
    
    // Calculate the offset for the GPIO set/clear register
    "MOV R2, %[pin]\n"
    "CMP %[value], #0\n"
    
    // If value is 0, clear the pin (use GPIO clear register)
    "ITE EQ\n"
    "STREQ R2, [R1, #0x28]\n"  // GPIO clear register offset (0x28)
    
    // If value is 1, set the pin (use GPIO set register)
    "STRNE R2, [R1, #0x1C]\n"  // GPIO set register offset (0x1C)
    
    // Output operands (none)
    : 
    
    // Input operands
    : [gpio] "m" (gpio), [pin] "r" (1 << led), [value] "r" (value)
    
    // Clobbered registers
    : "r1", "r2", "cc"
);
}


int readButton(uint32_t *gpio, int button) {
  uint32_t *button_address = gpio + (button * 4);  // Calculate the address of the button pin register
  int state;

  __asm__ volatile(
      "ldr %0, [%1]\n\t"  // Load the button pin state into the state variable
      : "=r"(state)
      : "r"(button_address)
      : "memory"
  );

  return state;  // Return the state of the button (HIGH or LOW)
}


void waitForButton(uint32_t *gpio, int button) {
  while (readButton(gpio, button) == LOW) {
      // Wait for the button to be pressed (HIGH)
  }
}

