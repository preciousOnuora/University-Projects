import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.util.ArrayList;
import java.util.Scanner;

public class MainWindow extends JFrame {

    ArrayList <Integer> entries = new ArrayList<Integer>();
	public int number;

    public MainWindow()
    {
        //acesses a random number from the text file
        readFile();
        
       // SudokuSolverGUI ss = new SudokuSolverGUI(this);

        // sets up the frame
		Container contain = getContentPane();
		setSize(800,800);
		setTitle("Suduko");

        setLayout(new GridLayout(9,9));
        contain.setBackground(Color.pink);
        
        for (int i = 0; i< 81; i++) {
        add(new JButton("1"));
        
        
        }
        


    }

    public void readFile()
    {
        try 
        {
             // reads in the file
			BufferedReader in = new BufferedReader(new FileReader("entries.txt"));
			Integer num = 0;
			//while ((num = Integer.parseInt(num))!= 0)
			{
				entries.add(num);
			}

			// gets a random number
			int length = entries.size();
			int index = (int) (Math.random() * length);
			number = entries.get(index);

		}
		catch (IOException e)
		{
			System.out.println("A error has occured");
		}
    }
}
