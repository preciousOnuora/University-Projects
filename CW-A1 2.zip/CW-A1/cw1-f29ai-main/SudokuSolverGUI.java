import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.List;
import java.util.ArrayList;


public class SudokuSolverGUI {

    private JFrame frame;
    private JTextField[][] cells = new JTextField[9][9];
    private JButton solveButton;
    private JButton resetButton;

    //metrics
    private JLabel stepsLabel;
    private JLabel backtracksLabel;
    private JLabel timeLabel;

    // difficulty dropdown menu
    private JComboBox<String> difficultyCombo;

    // reads txt file
    public static int[][] readFile(String filePath) throws IOException {
        File myFile = new File(filePath);
        // check to make sure files exist
        if (!myFile.exists()) {
            throw new IllegalArgumentException("File not found: " + filePath);
        }

        // stores each line read from the file (ignores empty cells)
        List<String> lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(myFile))) { // closes file after read
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    lines.add(line);
                }
            }
        }

        // constraint must be 9x9 grid
        if (lines.size() != 9) {
            throw new IllegalArgumentException("Expected 9 rows, found " + lines.size());
        }

        int[][] grid = new int[9][9];

        for (int r = 0; r < 9; r++) {
            String raw = lines.get(r);
            String[] tokens;

            // split up by spaces
            tokens = raw.trim().split("\\s+");

            if (tokens.length != 9) {
                throw new IllegalArgumentException(
                        "Row " + (r + 1) + " must have 9 cells (found " + tokens.length + ")");
            }

            for (int c = 0; c < 9; c++) {
                String t = tokens[c].trim();
                grid[r][c] = parseCellValue(t, r, c);
            }
        }

        return grid;
    }

    private static int parseCellValue(String token, int row, int col) {
        if (token.isEmpty() || token.equals(".")) { // if empty cell return 0
            return 0;
        }
        if (token.length() == 1 && Character.isDigit(token.charAt(0))) { // return cell
            int val = Integer.parseInt(token);
            if (val >= 1 && val <= 9)
                return val;
        }
        throw new IllegalArgumentException(
                "Invalid value '" + token + "' at row " + (row + 1) + ", column " + (col + 1));
    }

    public SudokuSolverGUI() {
        frame = new JFrame("Sudoku Solver");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(650, 650); // Slightly taller for dropdown
        frame.setLayout(new BorderLayout());

        JPanel gridPanel = new JPanel(new GridLayout(9, 9));

        // Difficulty dropdown with label
        JPanel difficultyPanel = new JPanel();
        difficultyPanel.setBackground(new Color(255, 233, 236)); // Soft pink
        difficultyPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel diffLabel = new JLabel("Difficulty:");
        diffLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        diffLabel.setForeground(new Color(255, 105, 180)); // Hot pink
        difficultyCombo = new JComboBox<>(new String[] { "Easy", "Medium", "Hard", "Advanced", "Impossible" });
        difficultyCombo.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        difficultyCombo.setBackground(new Color(255, 182, 193));
        difficultyCombo.setForeground(Color.WHITE);
        difficultyCombo.setBorder(BorderFactory.createLineBorder(new Color(255, 105, 180), 2, true));
        difficultyPanel.add(diffLabel);
        difficultyPanel.add(difficultyCombo);

        // Metrics panel with spacing and rounded border
        JPanel metricsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 0)); // More space between labels
        metricsPanel.setBackground(new Color(255, 233, 236));
        metricsPanel.setPreferredSize(new Dimension(400, 50));

        stepsLabel = new JLabel("Steps: 0", SwingConstants.CENTER);
        backtracksLabel = new JLabel("Backtracks: 0", SwingConstants.CENTER);
        timeLabel = new JLabel("Time: 0 ms", SwingConstants.CENTER);

        Font metricsFont = new Font("Comic Sans MS", Font.BOLD, 16);
        stepsLabel.setFont(metricsFont);
        backtracksLabel.setFont(metricsFont);
        timeLabel.setFont(metricsFont);

        stepsLabel.setForeground(new Color(255, 105, 180));
        backtracksLabel.setForeground(new Color(255, 105, 180));
        timeLabel.setForeground(new Color(255, 105, 180));

        // Set preferred size for better visibility
        stepsLabel.setPreferredSize(new Dimension(130, 40));
        backtracksLabel.setPreferredSize(new Dimension(160, 40));
        timeLabel.setPreferredSize(new Dimension(130, 40));

        metricsPanel.add(stepsLabel);
        metricsPanel.add(backtracksLabel);
        metricsPanel.add(timeLabel);

        // Combine difficulty and metrics in topPanel
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(255, 233, 236));
        // Set preferred size for topPanel to ensure enough space
        topPanel.setPreferredSize(new Dimension(500, 80));
        topPanel.add(difficultyPanel, BorderLayout.WEST);
        topPanel.add(metricsPanel, BorderLayout.CENTER);

        for (int row = 0; row < 9; row++) {
            for (int col = 0; col < 9; col++) {
                cells[row][col] = new JTextField();
                cells[row][col].setHorizontalAlignment(JTextField.CENTER);
                cells[row][col].setFont(new Font("Arial", Font.BOLD, 20));

                // Pink heart cells!!
                if (isHeartCell(row, col)) {
                    cells[row][col].setBackground(new Color(255, 182, 193)); // Light pink
                } else {
                    cells[row][col].setBackground(Color.WHITE);
                }

                // 3×3 borders
                int top = 1, left = 1, bottom = 1, right = 1;
                if (row % 3 == 0)
                    top = 3;
                if (col % 3 == 0)
                    left = 3;
                if (row == 8)
                    bottom = 3;
                if (col == 8)
                    right = 3;

                cells[row][col]
                        .setBorder(BorderFactory.createMatteBorder(top, left, bottom, right, new Color(255, 233, 236)));
                gridPanel.add(cells[row][col]);
                cells[row][col].setEditable(false); // cant edit

            }

        }

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        solveButton = createCuteButton("Solve");
        resetButton = createCuteButton("Reset");


        buttonPanel.add(solveButton);
        buttonPanel.add(resetButton);
        frame.add(gridPanel, BorderLayout.CENTER);
        frame.add(topPanel, BorderLayout.NORTH); // Use topPanel instead of metricsPanel
        frame.add(buttonPanel, BorderLayout.SOUTH);


        // Load the sudoku when difficulty changes
        difficultyCombo.addActionListener(e -> {
            try {
                int[][] sudoku = readFile(getFileForDifficulty());
                fillGrid(sudoku);

                // Reset metrics
                SudokuSolver.steps = 0;
                SudokuSolver.backtracks = 0;
                stepsLabel.setText("Steps: 0");
                backtracksLabel.setText("Backtracks: 0");
                timeLabel.setText("Time: 0 ms");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error loading file:\n" + ex.getMessage(),
                        "File Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        resetButton.addActionListener(e -> {
            try {
                int[][] sudoku = readFile(getFileForDifficulty());
                fillGrid(sudoku);

                // Reset metrics
                SudokuSolver.steps = 0;
                SudokuSolver.backtracks = 0;
                stepsLabel.setText("Steps: 0");
                backtracksLabel.setText("Backtracks: 0");
                timeLabel.setText("Time: 0 ms");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error loading file:\n" + ex.getMessage(),
                        "File Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        solveButton.addActionListener(e -> {
            int[][] grid = new int[9][9];

            // Read current grid from GUI
            for (int r = 0; r < 9; r++) {
                for (int c = 0; c < 9; c++) {
                    String text = cells[r][c].getText().trim();
                    grid[r][c] = text.isEmpty() ? 0 : Integer.parseInt(text);
                }
            }

            // Reset metrics
            SudokuSolver.steps = 0;
            SudokuSolver.backtracks = 0;

            // Measure execution time and solve
            long startTime = System.currentTimeMillis();
            boolean solved = SudokuSolver.solveSudoku(grid);
            long endTime = System.currentTimeMillis();
            long duration = endTime - startTime;

            if (solved) {
                // Fill GUI with solution
                for (int r = 0; r < 9; r++) {
                    for (int c = 0; c < 9; c++) {
                        cells[r][c].setText(String.valueOf(grid[r][c]));
                    }
                }
                JOptionPane.showMessageDialog(frame, "Sudoku solved!");
            } else {
                JOptionPane.showMessageDialog(frame, "No solution exists for this puzzle.");
            }

            // Update metrics labels
            stepsLabel.setText("Steps: " + SudokuSolver.steps);
            backtracksLabel.setText("Backtracks: " + SudokuSolver.backtracks);
            timeLabel.setText("Time: " + duration + " ms");
        });

        // Load sudoku file for selected difficulty when GUI opens
        try {
            int[][] sudoku = readFile(getFileForDifficulty());
            fillGrid(sudoku);
            System.out.println("Sudoku loaded successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error loading file:\n" + e.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
        }

        frame.setVisible(true);
    }

    // Fill the GUI cells with Sudoku numbers
    private void fillGrid(int[][] sudoku) {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (sudoku[r][c] != 0) {
                    cells[r][c].setText(String.valueOf(sudoku[r][c]));
                    cells[r][c].setEditable(false);
                } else {
                    cells[r][c].setText("");
                }
            }
        }
    }

    private static JButton createCuteButton(String text) {
        JButton button = new JButton(text);

        // Base pink!
        button.setBackground(new Color(255, 182, 193)); // light pink
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Comic Sans MS", Font.BOLD, 18));
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);

        button.setBorder(BorderFactory.createLineBorder(new Color(255, 105, 180), 3, true));
        button.setMargin(new Insets(10, 20, 10, 20));

        return button;
    }
    
private String getFileForDifficulty() {
    Object selected = difficultyCombo.getSelectedItem();
    if (selected == null) {
        return "sudoku.txt"; // default
    }

    String diff = selected.toString();
    switch (diff) {
        case "Easy": return "sudoku_easy.txt";
        case "Medium": return "sudoku_medium.txt";
        case "Hard": return "sudoku_hard.txt";
        case "Advanced": return "sudoku_advanced.txt";
         case "Impossible": return "sudoku_impossible.txt";
        default: return "sudoku.txt";
    }
}


    // Heart-shaped pink cell pattern!!!! so cute
    private boolean isHeartCell(int row, int col) {
        int[][] heartPattern = {
                { 0, 2 }, { 0, 3 }, { 0, 5 }, { 0, 6 },
                { 1, 1 }, { 1, 2 }, { 1, 3 }, { 1, 4 }, { 1, 5 }, { 1, 6 }, { 1, 7 },
                { 2, 0 }, { 2, 1 }, { 2, 3 }, { 2, 4 }, { 2, 5 }, { 2, 7 }, { 2, 8 },
                { 3, 0 }, { 3, 1 }, { 3, 4 }, { 3, 7 }, { 3, 8 },
                { 4, 0 }, { 4, 1 }, { 4, 7 }, { 4, 8 },
                { 5, 1 }, { 5, 2 }, { 5, 6 }, { 5, 7 },
                { 6, 2 }, { 6, 3 }, { 6, 5 }, { 6, 6 },
                { 7, 3 }, { 7, 4 }, { 7, 5 },
                { 8, 4 }
        };
        for (int[] pos : heartPattern) {
            if (pos[0] == row && pos[1] == col)
                return true;
        }
        return false;

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SudokuSolverGUI());

    }
}
