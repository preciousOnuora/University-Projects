public class SudokuSolver {

    // Solve the Sudoku using backtracking with pruning
    public static int steps = 0;
    public static int backtracks = 0;

    public static boolean solveSudoku(int[][] grid) {
        steps++; // count each recursive call

        int[] emptyPos = findEmptyCell(grid);
        if (emptyPos == null)
            return true;

        int row = emptyPos[0];
        int col = emptyPos[1];

        for (int num = 1; num <= 9; num++) {
            if (isSafe(grid, row, col, num)) {
                grid[row][col] = num;

                if (solveSudoku(grid))
                    return true;

                grid[row][col] = 0; // backtrack
                backtracks++; // count backtracking step
            }
        }

        return false;
    }

    // Find the next empty cell (represented by 0)
    private static int[] findEmptyCell(int[][] grid) {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (grid[r][c] == 0) {
                    return new int[] { r, c };
                }
            }
        }
        return null; // No empty cells
    }

    // canw we place a number in a cell?
    private static boolean isSafe(int[][] grid, int row, int col, int num) {
        return !usedInRow(grid, row, num) &&
                !usedInCol(grid, col, num) &&
                !usedInBox(grid, row - row % 3, col - col % 3, num);
    }

    // is the number used in the 3x3 row?
    private static boolean usedInRow(int[][] grid, int row, int num) {
        for (int c = 0; c < 9; c++) {
            if (grid[row][c] == num)
                return true;
        }
        return false;
    }

    // is the number used in the coloumn?
    private static boolean usedInCol(int[][] grid, int col, int num) {
        for (int r = 0; r < 9; r++) {
            if (grid[r][col] == num)
                return true;
        }
        return false;
    }

    // is the number used in the 3x3 box?
    private static boolean usedInBox(int[][] grid, int startRow, int startCol, int num) {
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (grid[startRow + r][startCol + c] == num)
                    return true;
            }
        }
        return false;
    }
}
