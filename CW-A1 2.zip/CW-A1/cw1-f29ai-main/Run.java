
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Run {

	public static void main(String[] args) {
		MainWindow main = new MainWindow();

		main.addWindowListener(new WindowAdapter() 
		{
			public void windowClosing(WindowEvent e) 
			{
				System.out.println("Window is closing");
				System.exit(0);
			}
			public void windowOpened(WindowEvent e) 
			{
				System.out.println("Window opened, welcome");
			}
		});

		// this makes the frame visible
		main.setVisible(true);
	}

}
